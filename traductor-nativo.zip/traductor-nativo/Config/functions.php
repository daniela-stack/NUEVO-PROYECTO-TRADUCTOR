<?php
    //Declaracion de funciones  y helpers
function saniText($texto){

    //$texto = mysql_real_escape_string($texto);    //filtramos los caracteres ingresados
    $texto = addslashes($texto);
    $texto = htmlspecialchars($texto);
    $texto = htmlentities($texto);

    return $texto;
}

?>