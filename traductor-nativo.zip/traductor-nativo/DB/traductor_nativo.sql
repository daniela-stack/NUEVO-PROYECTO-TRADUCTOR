-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 22-07-2021 a las 11:47:43
-- Versión del servidor: 10.4.20-MariaDB-log
-- Versión de PHP: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `traductor_nativo`
--
CREATE DATABASE IF NOT EXISTS `traductor_nativo` DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci;
USE `traductor_nativo`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `idiomas`
--

DROP TABLE IF EXISTS `idiomas`;
CREATE TABLE `idiomas` (
  `id` int(3) NOT NULL,
  `idioma` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `idiomas`
--

INSERT INTO `idiomas` (`id`, `idioma`) VALUES
(1, 'Español'),
(2, 'Ingles'),
(3, 'Francés'),
(4, 'Tucano');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `palabras`
--

DROP TABLE IF EXISTS `palabras`;
CREATE TABLE `palabras` (
  `id` int(9) NOT NULL,
  `palabra` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `id_tipo` int(2) NOT NULL,
  `id_idioma` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `palabras`
--

INSERT INTO `palabras` (`id`, `palabra`, `id_tipo`, `id_idioma`) VALUES
(1, 'se&ntilde;or', 1, 1),
(2, 'mister', 1, 2),
(3, 'se&ntilde;orita', 1, 1),
(4, 'miss', 1, 2),
(5, 'monsieur', 1, 3),
(6, 'mademoiselle', 1, 3),
(7, 'hombre', 1, 1),
(8, 'man', 1, 2),
(9, 'mujer', 1, 1),
(10, 'woman', 1, 2),
(11, 'hombres', 1, 1),
(12, 'men', 1, 2),
(13, 'mujeres', 1, 1),
(14, 'women', 1, 2),
(30, 'ni&ntilde;o', 1, 1),
(31, 'boy', 1, 2),
(32, 'testŨ', 5, 3),
(33, 'test', 5, 2),
(34, 'un', 4, 1),
(35, 'a', 4, 2),
(36, 'una', 0, 1),
(37, 'tall', 4, 2),
(38, 'alto', 4, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `relacion_palabras`
--

DROP TABLE IF EXISTS `relacion_palabras`;
CREATE TABLE `relacion_palabras` (
  `id` int(11) NOT NULL,
  `id_palabra_origen` int(11) NOT NULL,
  `id_palabra_traduccion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `relacion_palabras`
--

INSERT INTO `relacion_palabras` (`id`, `id_palabra_origen`, `id_palabra_traduccion`) VALUES
(1, 1, 2),
(2, 3, 4),
(3, 1, 5),
(4, 3, 6),
(5, 7, 8),
(6, 9, 10),
(7, 11, 12),
(8, 13, 14),
(15, 30, 31),
(16, 32, 33),
(17, 34, 35),
(18, 36, 35),
(19, 37, 38);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

DROP TABLE IF EXISTS `tipos`;
CREATE TABLE `tipos` (
  `id` int(2) NOT NULL,
  `tipo` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`id`, `tipo`) VALUES
(1, 'sujeto'),
(2, 'verbo'),
(3, 'objeto'),
(4, 'adjetivo'),
(5, 'general');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `idiomas`
--
ALTER TABLE `idiomas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `palabras`
--
ALTER TABLE `palabras`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `relacion_palabras`
--
ALTER TABLE `relacion_palabras`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipos`
--
ALTER TABLE `tipos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `idiomas`
--
ALTER TABLE `idiomas`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `palabras`
--
ALTER TABLE `palabras`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de la tabla `relacion_palabras`
--
ALTER TABLE `relacion_palabras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `tipos`
--
ALTER TABLE `tipos`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
