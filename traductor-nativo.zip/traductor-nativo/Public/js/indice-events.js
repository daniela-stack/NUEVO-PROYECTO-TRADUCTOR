window.onload = function(){


    async function cargaContenido(url, datos){

        let contenido = "";

        contenido = await $.post(url, datos).promise();

        return contenido;
    }

    function getFormData($form){

        var unindexed_array = $form.serializeArray();
        var indexed_array = {};
    
        $.map(unindexed_array, function(n, i){
            indexed_array[n['name']] = n['value'];
        });
    
        return indexed_array;
    }

    //validamos si existe un mensaje toast

    $(".form-agregar-palabra").on("submit", function(e){

        e.preventDefault();

        $(".loader-guardar-palabra").show();

        let url = $(this).attr('action');
        let datos =getFormData($(this));

        cargaContenido(url, datos).then(function(contenido){

            console.log(contenido);

            resultado = JSON.parse(contenido);
        
            if(resultado.mensaje != undefined){

                if($(".toast").length > 0){
                    $(".toast").text(resultado.mensaje);
                }else{
                    $('body').append('<span class="toast">'+resultado.mensaje+'</span>');
                }

                $(".toast").addClass("active");

                setTimeout(function(){
                    $(".toast").removeClass("active");
                }, 3000);
                
            }

            setTimeout(function(){

                $(".loader-guardar-palabra").hide();

            },300);
            
            $(".form-agregar-palabra")[0].reset();
        });


    });

    $(".caja-form-nueva-palabra>h2").on("click", function(e){

        if($(".caja-form-nueva-palabra").hasClass("activo")){

            $(".caja-form-nueva-palabra").removeClass("activo");

            $(".caja-form-nueva-palabra>h2 .icon-toggle").addClass("ion-chevron-down");
            $(".caja-form-nueva-palabra>h2 .icon-toggle").removeClass("ion-chevron-up");

        }else{
            $(".caja-form-nueva-palabra").addClass("activo");

            $(".caja-form-nueva-palabra>h2 .icon-toggle").removeClass("ion-chevron-down");
            $(".caja-form-nueva-palabra>h2 .icon-toggle").addClass("ion-chevron-up");
        }

    });

    $(".form-buscar-palabra").on("submit", function(e){

        e.preventDefault();

        let contenedor = $(".contenedor-resultado-busqueda");
        let url = $(this).attr('action');
        let busqueda = $(".form-buscar-palabra input[name=buscar-palabra]").val().trim();
        let resultado = {};

        if(busqueda != ""){

            contenedor.empty().hide();

            $(".loader-busqueda").show();

            let datos = {'busqueda': busqueda};

            cargaContenido(url, datos).then(function(contenido){

                resultado = JSON.parse(contenido);

                let html = "<h3>Palabras encontradas:</h3>";
                let numResultados = resultado.length;

                $.each(resultado, function(index, palabra){

                    let palabraBuscadaArr = palabra.palabra;

                    $.each(palabra.traducciones, function(indexT, traduccion){

                        html += "<div class='item-palabra-busqueda'>"
                                    +"<p>"+palabraBuscadaArr.idioma+" <span class='ion-ios-arrow-forward'></span> "+traduccion.idioma_traduccion+"</p> "
                                    +"<span>"+palabraBuscadaArr.palabra+"</span>"
                                    +"<span>"+traduccion.traduccion+"</span>"
                                +"</div>"; 
                    });

                });

                if(numResultados == 0){
                    html += "<b>Sin resultados</b>";
                }

                html +="<div class='clear'></div>";

                setTimeout(function(){

                    $(".loader-busqueda").hide();

                    contenedor.html(html).promise().done(function(){

                        $(this).show();
    
                    });

                },300);
            });

        }else{
            contenedor.empty().hide();
        }
    });

    $('#cmd').click(function () {   
        doc.fromHTML($('#content').html(), 15, 15, {
            'width': 170,
                'elementHandlers': specialElementHandlers
        });
        doc.save('sample-file.pdf');
    });


};