window.onload = function(){

    let limiteTexto = 300;

    //Estos son los id de idiomas que se van a seleccionar de forma predeterminada
    let idiomaEntrada = 1;
    let idiomaDestino = 2;

    let temporizadorEscritura = null;

    $(".s-idioma-izquierda").val(idiomaEntrada);
    $(".s-idioma-derecha").val(idiomaDestino);


    async function cargaContenido(url, datos){

        let contenido = "";

        contenido = await $.post(url, datos).promise();

        return contenido;
    }

    
    $(".textarea-traducir").on("keyup", function(e){

        if(temporizadorEscritura != null){
            clearTimeout(temporizadorEscritura);
        }

        let valor = $(this).val().trim();

        if(valor.length > limiteTexto){

            valor = valor.substring(0, limiteTexto);
            $(this).val(valor);
        }

        $(".contador-texto.contador-izquierdo").text(valor.length + " / "+limiteTexto);
        


        if(valor.length > 0){

            temporizadorEscritura = setTimeout(function(){

                //enviamos el texto a traducir
                $(".loader-guardar-palabra").show();

                let url = './?controlador=PalabrasController&accion=traducir';
                let datos = {'texto': valor,
                             'idioma_origen': $(".s-idioma-izquierda").val(),
                             'idioma_traduccion': $(".s-idioma-derecha").val()};
        
                cargaContenido(url, datos).then(function(contenido){

                    let areaTraductor = $(".area-resultado-traduccion");
                    
                    console.log(contenido);

                    resultado = JSON.parse(contenido);
                    console.log(resultado);

                    if(resultado.traduccion != undefined){

                        areaTraductor.html(resultado.traduccion);
                    }else{
                        areaTraductor.html('<span class="no-traduccion">Sin resultados</span>');
                    }
                });

            }, 500);

        }else{
            $(".area-resultado-traduccion").html('<span class="no-traduccion">¡ Hora de traducir !</span>');
        }


    });

    $(".invertir-idiomas").on("click", function(e){

        e.preventDefault();

        //tomamos los idiomas actuales
        let idiomaIzquierda = $(".s-idioma-izquierda").val();
        let idiomaDerecha = $(".s-idioma-derecha").val();

        //invertimos los valores
        $(".s-idioma-izquierda").val(idiomaDerecha);
        $(".s-idioma-derecha").val(idiomaIzquierda);

        //disparamos el evento keyup del traductor
        $(".textarea-traducir").keyup();

    });





};