<?php

class Idioma{

    public static function obtenerIdiomas(){

        $idiomas = [];
        
        $db=Db::generarConexion();

		$sql = $db->prepare('SELECT * FROM idiomas ORDER BY idioma ASC');
        $sql->execute();

        $idiomas = $sql->fetchAll(PDO::FETCH_ASSOC);

        return $idiomas;

    }

}

?>