<?php

class Palabra{

    public static function guardar($post){

        $db=Db::generarConexion();

        $idPalabraOrigen = null;
        $idPalabraTraduccion = null;

        $existeOrigen = false;
        $existeTraduccion = false;

        $data = [
            'palabra' => saniText($post['palabra-origen']),
            'tipo' => $post['tipo'],
            'idioma' => $post['idioma-origen'],
        ];

        $data2 = [
            'palabra' => saniText($post['palabra-traducida']),
            'tipo' => $post['tipo'],
            'idioma' => $post['idioma-traduccion'],
        ];

        //verificamos si ya existe la palabra de origen
        
        $sql = $db->prepare('SELECT id FROM palabras WHERE palabra = "'.$data['palabra'].'" AND id_idioma = "'.$data['idioma'].'" LIMIT 1');
        $sql->execute();

        $palabraDB = $sql->fetchAll(PDO::FETCH_ASSOC);

        if(count($palabraDB) == 0){

            //Como no existe la agregamos
            $sql = $db->prepare('INSERT INTO palabras(palabra, id_tipo, id_idioma) VALUES("'.$data['palabra'].'", "'.$data['tipo'].'", "'.$data['idioma'].'")');
            $sql->execute();

            //obtenemos el id insertado
            $idPalabraOrigen = $db->lastInsertId();

        }else{

            //obtenemos el id de la palabra existente
            $idPalabraOrigen = $palabraDB[0]['id'];

            $existeOrigen = true;
        }

        //verificamos si ya existe la palabra de traduccion
        $sql = $db->prepare('SELECT id FROM palabras WHERE palabra = "'.$data2['palabra'].'" AND id_idioma = "'.$data2['idioma'].'" LIMIT 1');
        $sql->execute();

        $palabraDB = $sql->fetchAll(PDO::FETCH_ASSOC);

        if(count($palabraDB) == 0){

            //Como no existe la agregamos
            $sql = $db->prepare('INSERT INTO palabras(palabra, id_tipo, id_idioma) VALUES("'.$data2['palabra'].'", "'.$data2['tipo'].'", "'.$data2['idioma'].'")');
            $sql->execute();

            //obtenemos el id insertado
            $idPalabraTraduccion = $db->lastInsertId();

        }else{

            //obtenemos el id de la palabra existente
            $idPalabraTraduccion = $palabraDB[0]['id'];

            $existeTraduccion = true;
        }

        
        if(!$existeOrigen || !$existeTraduccion){ // si no existia alguna de las palabras creamos la relacion

            $sql = $db->prepare('INSERT INTO relacion_palabras(id_palabra_origen, id_palabra_traduccion) VALUES("'.$idPalabraOrigen.'", "'.$idPalabraTraduccion.'")');
            $sql->execute();

            return ['mensaje' => 'Palabra agregada'];
            //header('Location: ./?controlador=InterfazController&accion=indice&mensaje=palabras%20agregadas');

        }else{
            return ['mensaje' => 'Ya existen estas palabras'];
            //header('Location: ./?controlador=InterfazController&accion=indice&mensaje=Ya%20existen%20las%20palabras');
        }

    }

    public static function buscar($busqueda){

        $db=Db::generarConexion();


        $busqueda = saniText($busqueda);
        $palabrasDB = [];
        $palabrasTraduccionDB = [];
        $palabrasTraduccionDBExtra = [];
        $listaPalabrasTraduccion = [];

        $sql = $db->prepare('SELECT palabras.id, palabras.palabra, tipos.tipo, idiomas.idioma 
                            FROM palabras 
                            LEFT JOIN idiomas ON palabras.id_idioma = idiomas.id 
                            LEFT JOIN tipos ON palabras.id_tipo = tipos.id
                            WHERE palabra LIKE "%'.$busqueda.'%" ORDER BY palabra ASC');
        $sql->execute();

        $palabrasDB = $sql->fetchAll(PDO::FETCH_ASSOC);

        //buscamos las traducciones de las palabras encontradas

        if(count($palabrasDB) > 0){

            //generamos el string de la clausula where para la palabra como origen
            $cadenaCondicion = [];
            foreach ($palabrasDB as $palabraArr) {
                $cadenaCondicion[] = ' relacion_palabras.id_palabra_origen = "'.$palabraArr['id'].'" ';
            }

            $query = 'SELECT palabras.id AS id_traduccion, palabras.palabra AS traduccion, idiomas.idioma AS idioma_traduccion, relacion_palabras.id_palabra_origen AS id_palabra_origen  
            FROM relacion_palabras
            LEFT JOIN palabras ON relacion_palabras.id_palabra_traduccion = palabras.id
            LEFT JOIN idiomas ON palabras.id_idioma = idiomas.id
            WHERE '.implode('OR', $cadenaCondicion).' ';

            $sql = $db->prepare($query);
            $sql->execute();
            $palabrasTraduccionDB = $sql->fetchAll(PDO::FETCH_ASSOC);

            //generamos el string de la clausula where para la palabra como traduccion
            $cadenaCondicion = [];
            foreach ($palabrasDB as $palabraArr) {
                $cadenaCondicion[] = ' relacion_palabras.id_palabra_traduccion = "'.$palabraArr['id'].'" ';
            }

            $query = 'SELECT palabras.id AS id_traduccion, palabras.palabra AS traduccion, idiomas.idioma AS idioma_traduccion, relacion_palabras.id_palabra_traduccion AS id_palabra_traduccion   
            FROM relacion_palabras
            LEFT JOIN palabras ON relacion_palabras.id_palabra_origen = palabras.id
            LEFT JOIN idiomas ON palabras.id_idioma = idiomas.id
            WHERE '.implode('OR', $cadenaCondicion).' ';

            $sql = $db->prepare($query);
            $sql->execute();
            $palabrasTraduccionDBExtra = $sql->fetchAll(PDO::FETCH_ASSOC);



            //Ordenamos el array final emparejando las palabras buscadas con sus traducciones
            foreach ($palabrasDB as $key => $palabra) {
                
                $listaPalabrasTraduccion[$key] = [
                                            'palabra' => $palabra,
                                            'traducciones' => []
                ];

                //recorremos las traducciones para irlas agregando a la lista final
                foreach ($palabrasTraduccionDB as $traduccion) {
                    if($traduccion['id_palabra_origen'] == $palabra['id']){
                        $listaPalabrasTraduccion[$key]['traducciones'][] = $traduccion; 
                    }
                }


                //recorremos las traducciones extras para irlas agregando a la lista final
                foreach ($palabrasTraduccionDBExtra as $traduccion) {
                    if($traduccion['id_palabra_traduccion'] == $palabra['id']){
                        $listaPalabrasTraduccion[$key]['traducciones'][] = $traduccion;
                    }
                }

            }


        }




        //return array_merge($palabrasDB, $palabrasTraduccionDB, $palabrasTraduccionDBExtra);
        return $listaPalabrasTraduccion;

    }

    public static function obtenerTodas(){

        $db=Db::generarConexion();

        $sql = $db->prepare('SELECT palabras.palabra, idiomas.idioma 
                                FROM palabras 
                                LEFT JOIN idiomas ON palabras.id_idioma = idiomas.id 
                                ORDER BY palabra ASC');
        $sql->execute();

        $palabrasDB = $sql->fetchAll(PDO::FETCH_ASSOC);

        return $palabrasDB;

    }

    public static function traducir($post){

        $db=Db::generarConexion();


        $texto = saniText($post['texto']);
        $idiomaOrigen = $post['idioma_origen'];
        $idiomaTraduccion = $post['idioma_traduccion'];
        $palabraDB = [];
        $palabrasDB = [];
        $resultado = [];

        //dividimos el texto para verificar si es una palabra o una frase
        $palabrasArr = explode(' ', $texto);

        if(count($palabrasArr) == 1){
            //es una palabra, buscamos la traduccion

            //buscamos la palabra para obtener el id
            $sql = $db->prepare('SELECT id, id_tipo FROM palabras WHERE palabra = "'.$palabrasArr[0].'" AND id_idioma = "'.$idiomaOrigen.'" LIMIT 1');
            $sql->execute();

            $palabraDB = $sql->fetchAll(PDO::FETCH_ASSOC);

            //si encontramos la palabra
            if(!empty($palabraDB)){

                $palabraDB = $palabraDB[0];

                //procedemos a buscar sus traducciones
                $sql = $db->prepare('SELECT palabras.palabra, idiomas.id AS id_idioma
                                        FROM relacion_palabras
                                        LEFT JOIN palabras ON relacion_palabras.id_palabra_traduccion = palabras.id 
                                        LEFT JOIN idiomas ON palabras.id_idioma = idiomas.id
                                     WHERE (relacion_palabras.id_palabra_origen = "'.$palabraDB['id'].'" OR relacion_palabras.id_palabra_traduccion = "'.$palabraDB['id'].'" ) AND idiomas.id = "'.$idiomaTraduccion.'" ');
                
                $sql->execute();

                $traduccionDB = $sql->fetchAll(PDO::FETCH_ASSOC);
                
                //cambiamos la busqueda de origenes a traducciones
                $sql = $db->prepare('SELECT palabras.palabra, idiomas.id AS id_idioma
                                        FROM relacion_palabras
                                        LEFT JOIN palabras ON relacion_palabras.id_palabra_origen = palabras.id 
                                        LEFT JOIN idiomas ON palabras.id_idioma = idiomas.id
                                    WHERE (relacion_palabras.id_palabra_origen = "'.$palabraDB['id'].'" OR relacion_palabras.id_palabra_traduccion = "'.$palabraDB['id'].'" ) AND idiomas.id = "'.$idiomaTraduccion.'" ');
                $sql->execute();
    
                $traduccionExtraDB = $sql->fetchAll(PDO::FETCH_ASSOC);

                $traduccionesDB = array_merge($traduccionDB, $traduccionExtraDB);
                if(count($traduccionesDB) > 0){

                    $resultado = ['traduccion' => $traduccionDB[0]['palabra'],
                                'traducciones' => array_merge($traduccionDB, $traduccionExtraDB)];
                }else{
                    $resultado = [];
                }

            }


        }else{
            //son varias palabras buscamos sus traducciones


            //primero creamos la cadena de condiciones para todas las palabras
            $cadenaCondicion = [];

            foreach ($palabrasArr as $palabraTexto) {
                $cadenaCondicion[] = ' (palabra = "'.$palabraTexto.'" AND id_idioma="'.$idiomaOrigen.'") ';
            }

            $sql = $db->prepare('SELECT id, palabra, id_tipo FROM palabras WHERE '.implode('OR', $cadenaCondicion));
            $sql->execute();

            $palabrasDB = $sql->fetchAll(PDO::FETCH_ASSOC);

            //si encontramos las palabras buscamos sus traducciones
            if(count($palabrasDB) > 0){


                $cadenaCondicion = [];

                foreach ($palabrasDB as $palabra) {
                    $cadenaCondicion[] = '  (relacion_palabras.id_palabra_origen = "'.$palabra['id'].'" OR relacion_palabras.id_palabra_traduccion = "'.$palabra['id'].'" AND idiomas.id = "'.$idiomaTraduccion.'" )  ';
                }


                $sql = $db->prepare('SELECT palabras.palabra, idiomas.id AS id_idioma, relacion_palabras.id_palabra_origen AS id_origen
                                        FROM relacion_palabras
                                        LEFT JOIN palabras ON relacion_palabras.id_palabra_traduccion = palabras.id 
                                        LEFT JOIN idiomas ON palabras.id_idioma = idiomas.id
                                     WHERE '.implode('OR', $cadenaCondicion));
                $sql->execute();
                $traduccionDB = $sql->fetchAll(PDO::FETCH_ASSOC);

                //cambiamos la busqueda de origenes a traducciones

                $sql = $db->prepare('SELECT palabras.palabra, idiomas.id AS id_idioma, relacion_palabras.id_palabra_traduccion AS id_origen
                                        FROM relacion_palabras
                                        LEFT JOIN palabras ON relacion_palabras.id_palabra_origen = palabras.id 
                                        RIGHT JOIN idiomas ON palabras.id_idioma = "'.$idiomaTraduccion.'"
                                    WHERE '.implode('OR', $cadenaCondicion));
                $sql->execute();
                $traduccionExtraDB = $sql->fetchAll(PDO::FETCH_ASSOC);


                $traduccionesDB = array_merge($traduccionDB, $traduccionExtraDB);
                //ahora recorremos el texto original para crear la frase de traduccion en orden de llegada
                $traduccionTexto = "";

                foreach ($palabrasArr  as $key => $palabraBusqueda) {
                    
                    $palabrainicialEncontrada = false;

                    foreach ($palabrasDB as $palabraDB) {

                        $palabraEncontrada = false;
                        
                        if($palabraDB['palabra'] == $palabraBusqueda){

                            foreach ($traduccionesDB as $traduccion) {
                                
                                if($traduccion['id_origen'] == $palabraDB['id']  && !$palabraEncontrada){
                                    $traduccionTexto .= $traduccion['palabra'].' ';
                                    $palabraEncontrada = true;
                                    $palabrainicialEncontrada = true;
                                }
                            }

                        }
                    }

                    if(!$palabrainicialEncontrada){
                        $traduccionTexto .= '<span class="palabra-no-traducida">'.$palabraBusqueda.'</span> ';
                    }

                }


                $resultado = ['traduccion' => $traduccionTexto,
                              'traducciones' => $traduccionesDB];

            }

        }

        return $resultado;
    }
}

?>