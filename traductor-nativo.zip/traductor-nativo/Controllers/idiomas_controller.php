<?php

class IdiomasController{

    public static function obtenerIdiomas(){

        return Idioma::obtenerIdiomas();
    }

}

?>