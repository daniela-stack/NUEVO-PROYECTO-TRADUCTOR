<?php

class InterfazController{

    public static function cargaVista($vista){
        return file_get_contents('views/'.$vista.'.html');
    }

    public static function inicio(){

        $plantilla = self::cargaVista('plantilla');
        $traductor = self::cargaVista('traductor');

        //consultamos la lista de idiomas
        $idiomas = IdiomasController::obtenerIdiomas();

        $html = "";

        foreach ($idiomas as $idioma) {
            $html .= "<option value='".$idioma['id']."'>".$idioma['idioma']."</option>";
        }


        //incluimos los idiomas en la lista de idiomas del selector
        $traductor = str_replace('{idiomas}', $html, $traductor);
        $traductor = str_replace('{idiomasDestino}', $html, $traductor);

        //incluimos el contenido en la plantilla
        $plantilla = str_replace('{contenido}', $traductor, $plantilla);

        //mostramos la vista completa
        echo $plantilla;

    }

    public static function indice($get){
        

        $plantilla = self::cargaVista('plantilla');
        $indice = self::cargaVista('indice');

        //consultamos la lista de idiomas
        $idiomas = IdiomasController::obtenerIdiomas();

        //consultamos la lista de tipos de palabras
        $tipos = TiposController::obtenerTipos();

        $htmlIdiomas = "<option value='0'>[Seleccione un idioma]</option>";

        foreach ($idiomas as $idioma) {
            $htmlIdiomas .= "<option value='".$idioma['id']."'>".$idioma['idioma']."</option>";
        }

        $htmlTipos = "<option value='0'>[Seleccione el tipo de palabra]</option>";

        foreach ($tipos as $tipo) {
            $htmlTipos .= "<option value='".$tipo['id']."'>".$tipo['tipo']."</option>";
        }

        //incluimos los idiomas en la lista de idiomas del selector
        $indice = str_replace('{idiomas}', $htmlIdiomas, $indice);

        //incluimos los tipos en la lista de tipos del selector
        $indice = str_replace('{tipos}', $htmlTipos, $indice);

        //incluimos el contenido en la plantilla
        $plantilla = str_replace('{contenido}', $indice, $plantilla);

        //mostramos la vista completa
        echo $plantilla;
    }

    public static function palabras(){

        $plantilla = self::cargaVista('plantilla');
        $lista = self::cargaVista('lista');

        //consultamos la lista de palabras
        $palabras = PalabrasController::obtenerTodas();
        
        $html = "";
        foreach ($palabras as $palabra) {
            $html .= "<div class='item-lista-palabra'>
                        <span>".$palabra['palabra']."</span>
                        <b>".$palabra['idioma']."</b>
                      </div>";
        }

        //incluimos la lista de palabras en la plantilla de la lista
        $lista = str_replace('{palabras}', $html, $lista);

        //incluimos el contenido en la plantilla
        $plantilla = str_replace('{contenido}', $lista, $plantilla);

        //mostramos la vista completa
        echo $plantilla;

        
    }

}

?>