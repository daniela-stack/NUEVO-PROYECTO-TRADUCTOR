<?php

class Tiposcontroller{

    public static function obtenerTipos(){

        return Tipo::obtenerTipos();

    }

}

?>